-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2021 at 04:09 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `minicontact`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `phone`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Conrad Connelly', '+1 (513) 896-0540', 'linda.runolfsdottir@example.org', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(2, 'Rosamond Stokes', '1-401-282-3637', 'leda.kessler@example.com', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(3, 'Reba Graham', '(897) 963-1057', 'murray66@example.org', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(4, 'Ethan Langosh', '+1 (371) 373-9360', 'yesenia.quigley@example.net', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(5, 'Ellie Mosciski', '(371) 685-7326', 'vyundt@example.net', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(6, 'Dr. Wilford Breitenberg', '1-817-935-3975', 'hagenes.dakota@example.net', '2021-01-29 07:17:22', '2021-01-29 07:17:22'),
(7, 'Nova Lind MD', '(273) 231-4291', 'bins.kaleb@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(8, 'Layne Yundt', '545-330-8460', 'gordon71@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(9, 'Hilario Lowe', '786.646.2800', 'hjacobs@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(10, 'Dr. Bud Cummerata', '+14355042549', 'nvandervort@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(11, 'Mrs. Alda Ebert II', '1-748-206-4607', 'roberto.hyatt@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(12, 'Nikita Okuneva', '+1 (864) 368-5255', 'bonnie21@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(13, 'Amir Effertz', '+1-763-488-1417', 'billie44@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(14, 'Wyman Schimmel', '1-772-566-9317', 'yasmeen94@example.net', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(15, 'Giles Corkery', '+13154440302', 'kallie55@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(16, 'Abdul Rolfson', '+14377166006', 'matteo.fisher@example.net', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(17, 'Jameson Crooks', '262.558.6114', 'friesen.courtney@example.net', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(18, 'Mina Hill', '+15613468658', 'abdul.vandervort@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(19, 'Mrs. Brenda Steuber Sr.', '1-701-658-2950', 'dee98@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(20, 'Lillie McDermott', '+1 (264) 769-5574', 'usimonis@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(21, 'Miss Chyna McLaughlin DDS', '(926) 542-9853', 'farrell.avis@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(22, 'Esta Huels', '+1-607-307-7904', 'grayce.gutmann@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(23, 'Fae Farrell IV', '1-378-316-4824', 'ursula.flatley@example.org', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(24, 'Prof. Flavio Mayer DVM', '+1.382.900.0291', 'tevin02@example.net', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(25, 'Yasmeen Quitzon', '(882) 604-4459', 'vhyatt@example.com', '2021-01-29 07:17:23', '2021-01-29 07:17:23'),
(26, 'Kayden Keebler', '+1 (658) 217-7117', 'mbashirian@example.net', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(27, 'Effie McLaughlin', '+12793044319', 'fletcher.davis@example.com', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(28, 'Jeremie Kihn', '+1-582-818-7619', 'belle.schultz@example.com', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(29, 'Raymond Eichmann', '+1.581.579.2126', 'timmothy30@example.com', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(30, 'Augustus Smith I', '+1-291-758-4376', 'karson.hudson@example.net', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(31, 'Raheem Mohr', '864-238-6411', 'barton.kiana@example.com', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(32, 'Paris Schuster', '561.820.3568', 'dibbert.antone@example.org', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(33, 'Loyce Spencer', '942.731.7867', 'nickolas81@example.org', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(34, 'Ova Aufderhar', '+1-504-371-6148', 'lnolan@example.net', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(35, 'Samantha Schamberger', '(907) 613-3956', 'bernhard.otha@example.org', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(36, 'Prof. Linwood Ondricka IV', '(506) 743-9626', 'anabel.koss@example.net', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(37, 'Rhianna Kozey', '1-881-394-1693', 'khayes@example.com', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(38, 'Mr. Hank Weber III', '+13723338628', 'vconsidine@example.org', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(39, 'Robyn Beahan', '+1-509-277-0477', 'shanelle13@example.net', '2021-01-29 07:17:24', '2021-01-29 07:17:24'),
(40, 'Clinton Mayer II', '905-341-1411', 'jazlyn.kassulke@example.org', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(41, 'Ms. Lisette Lockman', '635-404-7292', 'samir99@example.com', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(42, 'Oscar Bradtke IV', '(970) 543-7041', 'goyette.cara@example.org', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(43, 'Mr. Holden Hirthe', '993-901-2405', 'cyrus.ryan@example.net', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(44, 'Penelope Huels MD', '+1.874.462.9615', 'nash34@example.org', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(45, 'Kailyn Kilback V', '+1 (864) 236-1137', 'nboehm@example.com', '2021-01-29 07:17:25', '2021-01-29 07:17:25'),
(46, 'Patricia Grady', '539.850.1377', 'elmore.glover@example.net', '2021-01-29 07:17:26', '2021-01-29 07:17:26'),
(47, 'Tillman Hamill Jr.', '1-639-642-1265', 'dswaniawski@example.com', '2021-01-29 07:17:26', '2021-01-29 07:17:26'),
(48, 'Arturo Schiller', '790-835-7691', 'dietrich.randi@example.org', '2021-01-29 07:17:26', '2021-01-29 07:17:26'),
(49, 'Mr. Allan Kihn', '869-419-4940', 'colten78@example.org', '2021-01-29 07:17:26', '2021-01-29 07:17:26'),
(50, 'Dr. Greyson Breitenberg DDS', '1-237-674-7551', 'ziemann.seth@example.org', '2021-01-29 07:17:26', '2021-01-29 07:17:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_01_29_145359_create_contacts_table', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
